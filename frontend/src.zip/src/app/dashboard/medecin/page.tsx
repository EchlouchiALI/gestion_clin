"use client";

import { useEffect, useState } from "react";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

// ✅ Types
type Medecin = {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  specialite?: string;
  telephone?: string;
};

type Patient = {
  id: number;
  nom: string;
  prenom: string;
  email: string;
  telephone?: string;
};

type RendezVous = {
  id: number;
  date: string;
  heure: string;
  motif: string;
  statut: "à venir" | "passé" | "annulé";
  patient: Patient;
};

export default function DashboardMedecinPage() {
  const [medecin, setMedecin] = useState<Medecin | null>(null);
  const [rdvs, setRdvs] = useState<RendezVous[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      console.error("Aucun token trouvé");
      return;
    }

    const fetchData = async () => {
      try {
        const headers = { Authorization: `Bearer ${token}` };

        const [medRes, rdvRes] = await Promise.all([
          fetch("http://localhost:3000/admin/medecins/me/profile", { headers }),
          fetch("http://localhost:3000/admin/medecins/me/rendezvous", { headers }),
        ]);

        if (!medRes.ok || !rdvRes.ok) {
          const text1 = await medRes.text();
          const text2 = await rdvRes.text();
          console.error("Erreur API :", text1, text2);
          return;
        }

        const medecinData = await medRes.json();
        const rdvData = await rdvRes.json();

        setMedecin(medecinData);
        setRdvs(rdvData);
      } catch (error) {
        console.error("Erreur lors du chargement :", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) return <div className="p-10 text-white">Chargement...</div>;

  const rdvsAujourdhui = rdvs.filter(
    (rdv) => rdv.date === format(new Date(), "yyyy-MM-dd")
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-pink-800 text-white p-6 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">
            Bonjour Dr. {medecin?.prenom} {medecin?.nom}
          </h1>
          <p className="text-purple-200 text-sm">{medecin?.specialite}</p>
        </div>
        <Button className="bg-white/20 text-white hover:bg-white/30">
          <LogOut className="w-4 h-4 mr-2" /> Déconnexion
        </Button>
      </header>

      {/* Statistiques */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white/10">
          <CardContent className="p-4">
            <p className="text-white/60">Total Rendez-vous</p>
            <h2 className="text-2xl font-bold">{rdvs.length}</h2>
          </CardContent>
        </Card>
        <Card className="bg-white/10">
          <CardContent className="p-4">
            <p className="text-white/60">Aujourd'hui</p>
            <h2 className="text-2xl font-bold">{rdvsAujourdhui.length}</h2>
          </CardContent>
        </Card>
        <Card className="bg-white/10">
          <CardContent className="p-4">
            <p className="text-white/60">En attente</p>
            <h2 className="text-2xl font-bold">
              {rdvs.filter((r) => r.statut === "à venir").length}
            </h2>
          </CardContent>
        </Card>
      </div>

      {/* Liste des rendez-vous à venir */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold">Rendez-vous à venir</h2>
        {rdvs
          .filter((r) => r.statut === "à venir")
          .map((rdv) => (
            <Card key={rdv.id} className="bg-white/10">
              <CardContent className="p-4 flex justify-between items-center">
                <div>
                  <p className="text-lg font-medium">
                    {rdv.patient.nom} {rdv.patient.prenom}
                  </p>
                  <p className="text-sm text-white/70">{rdv.motif}</p>
                  <p className="text-xs text-white/50">
                    {format(new Date(rdv.date), "dd/MM/yyyy")} à {rdv.heure}
                  </p>
                </div>
                <Badge>{rdv.statut}</Badge>
              </CardContent>
            </Card>
          ))}
        {rdvs.filter((r) => r.statut === "à venir").length === 0 && (
          <p className="text-white/60 italic">Aucun rendez-vous à venir</p>
        )}
      </div>
    </div>
  );
}
